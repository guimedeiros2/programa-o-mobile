function somar(){
    var media = document.getElementByld('media')
    var br1 = document.getElementByld('media1')
    var br2 = document.getElementByld('media2')
    var br3 = document.getElementByld('media3')
    var br1 =Number(br1.value)
    var br2 =Number(br2.value)
    var br3 =Number(br3.value)
var valor = (br1 * 2 + br2 * 3 + br3 * 5)/10
document.getElementByid


}